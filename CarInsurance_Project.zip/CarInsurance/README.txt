
# CarInsurance - ASP.NET MVC Insurance Quote Project

This folder contains the key files for the **CarInsurance** MVC project used in the Tech Academy assignment:

- `Models/Insuree.cs` — Insuree model with all fields, including Quote
- `Models/InsuranceEntities.cs` — Entity Framework DbContext
- `Controllers/InsureeController.cs` — Controller with full quote calculation logic and Admin action
- `Views/Insuree/Create.cshtml` — Create view (Quote field hidden)
- `Views/Insuree/Index.cshtml` — List view
- `Views/Insuree/Admin.cshtml` — Admin view listing all quotes

To use in your existing Visual Studio MVC project:

1. Create a new ASP.NET MVC project named **CarInsurance** in Visual Studio.
2. Replace or add these files into the matching folders:
   - Copy `Insuree.cs` and `InsuranceEntities.cs` into the **Models** folder.
   - Copy `InsureeController.cs` into the **Controllers** folder.
   - Create an **Insuree** folder under **Views** and copy all `.cshtml` files there.
3. Ensure your `Web.config` connection string is named `DefaultConnection` or update `InsuranceEntities` constructor accordingly.
4. Enable migrations / update database or let EF create the Insurees table.

You can now build and run the project, create quotes, and view them in the Admin page (`/Insuree/Admin`).
